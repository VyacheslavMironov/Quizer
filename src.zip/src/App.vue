<template>
  <HeaderComponent>
  </HeaderComponent>
  <ModalComponent />
  <main>
    <div class="container">
      <div class="row mt-5">
        <div class="col-6">
          <img src="@/assets/image/vopros.jpg" class="img-fluid">
          <br>
          <ButtonComponent 
            btn="Пройти опрос"
            type="Modal"
           />
        </div>
        <div class="col-6">
          <h3 class="text-center">Пройдите опрос</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis temporibus a in rerum, commodi doloremque ipsam impedit facere veniam ex ab fugit hic? Sit accusantium labore aliquid numquam hic at.
          Voluptates culpa dicta necessitatibus! Iusto quam illum ab nihil repudiandae. Similique, eaque quasi quaerat reiciendis exercitationem dignissimos repellendus sed eius earum cumque quisquam voluptatem distinctio ea sunt repellat ut iusto.
          Velit cumque dignissimos nobis temporibus, aliquam corrupti et pariatur culpa consequuntur deserunt, cum magni fugit dicta minima aperiam placeat omnis distinctio aliquid at porro. Laborum, quisquam! Numquam suscipit consequuntur nostrum.</p>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import ButtonComponent from '@/components/ButtonComponent.vue'
import HeaderComponent from '@/components/HeaderComponent.vue'
import ModalComponent from '@/components/ModalComponent.vue'

export default {
  name: 'App',
  data() {
    return {
     
    }
  },
  components: {
    ButtonComponent,
    HeaderComponent,
    ModalComponent
  }
}
</script>

<template>
    <form>
        <div 
            v-for="(el, ids) in variant"
            v-bind:key="el"
            class="mb-3"
        >
            <div class="form-check">
                <input 
                    class="form-check-input" 
                    type="radio" 
                    name="variant" 
                    id="flexCheckDefault"
                    v-bind:value="variant[ids]"
                    v-model="data_variant"
                >
                <label class="form-check-label" for="flexCheckDefault">
                    {{ el }}
                </label>
            </div>
        </div>
        <button type="button" class="btn btn-primary">Submit</button>
    </form>
</template>

<script>
    export default {
        data() {
            return {
                data_variant: "",
                variant: ["Животные", "Красота и здоровье"]
            }
        },
        methods: {
        }
    }
</script>